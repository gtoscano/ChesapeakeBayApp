import csv

import csv
 
# opening the CSV file
with open('84_load_source.csv', mode ='r') as file:
   
  # reading the CSV file
  csvFile = csv.reader(file)
 
  # displaying the contents of the CSV file
  a = []
  lrs = {}
  load_sources = {}
  agencies = {}
  cnt = 0
  for lines in csvFile:
      if cnt == 0:
          cnt += 1
          continue
      lrs[lines[1]]=0
      agencies[lines [2]] = 0
      load_sources[lines[3]]=0
  print(len(lrs.keys()))
  print(len(agencies.keys()))
  print(len(load_sources.keys()))


        
